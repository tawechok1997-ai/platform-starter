export class WalletsModule {}
