export class WalletLedgerModule {}
