export class AdminQueueModule {}
