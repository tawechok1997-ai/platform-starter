export class ProviderSignatureGuard {}
