export class ProviderIpGuard {}
