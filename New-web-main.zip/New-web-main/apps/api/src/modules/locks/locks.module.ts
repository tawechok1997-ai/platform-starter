export class LocksModule {}
