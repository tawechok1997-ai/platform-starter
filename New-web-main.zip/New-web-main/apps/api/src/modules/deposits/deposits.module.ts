export class DepositsModule {}
